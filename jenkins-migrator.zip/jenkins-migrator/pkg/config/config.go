package config

import (
	"log"

	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

var GlobalConfig Config

type Config struct {
	Providers []Providers `yaml:"providers"`
}

type Providers struct {
	Name    string `yaml:"name"`
	Source  string `yaml:"source"`
	Version string `yaml:"version"`
}

func initConfig() {
	viper.AddConfigPath(".")      // or any path where your config file resides
	viper.SetConfigName("config") // no need to include file extension
	viper.SetConfigType("yaml")   // this depends on your config file format

	viper.AutomaticEnv() // override settings in config file with environment variables

	if err := viper.ReadInConfig(); err != nil {
		log.Fatalf("Error reading config file, %s", err)
	}

	if err := viper.Unmarshal(&GlobalConfig); err != nil {
		log.Fatalf("Unable to decode into struct, %v", err)
	}

}

func init() {
	cobra.OnInitialize(initConfig)
	// Other initialization code...
}
