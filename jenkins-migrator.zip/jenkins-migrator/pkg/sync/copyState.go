package sync

import (
	"context"
	"fmt"
	"path/filepath"

	"cloud.google.com/go/storage"
)

// CopyObject copies an object from a source bucket to the destination bucket.
func CopyObject(ctx context.Context, srcBucket, destBucket, srcObject, destPath string) error {
	client, err := storage.NewClient(ctx)
	if err != nil {
		return fmt.Errorf("storage.NewClient: %w", err)
	}
	defer client.Close()

	src := client.Bucket(srcBucket).Object(srcObject)

	destObject := fmt.Sprintf("%s/%s", destPath, filepath.Base(srcObject))
	dest := client.Bucket(destBucket).Object(destObject)

	dest = dest.If(storage.Conditions{DoesNotExist: true})

	if _, err := dest.CopierFrom(src).Run(ctx); err != nil {
		return fmt.Errorf("Object(%q).CopierFrom(%q).Run: %w", destObject, srcObject, err)
	}

	fmt.Printf("Successfully copied %v in bucket %v to blob %v in bucket %v.\n", srcObject, srcBucket, destObject, destBucket)
	return nil
}
