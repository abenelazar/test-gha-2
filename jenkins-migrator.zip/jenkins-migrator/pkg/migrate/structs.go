package migrate

type Manifest struct {
	Config Config `json:"config"`
}

type BranchSettings struct {
	Master Master `json:"master"`
}

type Master struct {
	Stream string `json:"stream"`
}

type Config struct {
	BranchSettings      BranchSettings               `json:"branchSettings"`
	PipelineSettings    PipelineSettings             `json:"pipelineSettings"`
	StreamSettings      StreamSettings               `json:"streamSettings"`
	EnvironmentSettings map[string]SettingsContainer `json:"environmentSettings"` // todo fix this
}

type StreamSettings struct {
	Teststream Teststream `json:"teststream"`
}

type Teststream struct {
	Environments []string `json:"environments"`
}

// type EnvironmentSettings struct {
// 	DigitalDfpPegasus DigitalDfpPegasus `json:"digital-dfp-pegasus"`
// }

// type DigitalDfpPegasus struct {
// 	SettingsEnvironmentSettings SettingsEnvironmentSettings `json:"settings"`
// }

type SettingsContainer struct {
	SettingsEnvironmentSettings SettingsEnvironmentSettings `json:"settings"`
}

type SettingsEnvironmentSettings struct {
	Infrastructure         Infrastructure `json:"infrastructure"`
	DeployCredentialID     string         `json:"deployCredentialId"`
	DeployApprovalRequired bool           `json:"deployApprovalRequired"`
	DeployApprovers        string         `json:"deployApprovers"`
	DeployApproversEmail   string         `json:"deployApproversEmail"`
}

type PipelineSettings struct {
	Stages          []string        `json:"stages"`
	JenkinsNode     string          `json:"jenkinsNode"`
	GenericSettings GenericSettings `json:"genericSettings"`
	StageSettings   StageSettings   `json:"stageSettings"`
}

type GenericSettings struct {
	GlobalNotificationSettings GlobalNotificationSettings `json:"globalNotificationSettings"`
}

type GlobalNotificationSettings struct {
	Mail       Mail       `json:"mail"` // todo fix this
	Mattermost Mattermost `json:"mattermost"`
}

type Mail struct {
	Enabled     bool   `json:"enabled"`
	To          string `json:"to"`
	AttachLog   bool   `json:"attachLog"`
	CompressLog bool   `json:"compressLog"`
	ReplyTo     string `json:"replyTo"`
}

type Infrastructure struct {
	CloudProvider      string `json:"cloudProvider"`
	JenkinsSlaveIPCidr string `json:"jenkins_slave_ip_cidr"`
	Gcp                Gcp    `json:"gcp"`
}

type Gcp struct {
	ProjectName                            string                    `json:"project_name"`
	ClusterName                            string                    `json:"cluster_name"`
	ProjectEnvType                         string                    `json:"project_env_type"`
	Region                                 string                    `json:"region"`
	InfraServiceAccountAsJenkinsSecretFile string                    `json:"infra_service_account_as_jenkins_secret_file"`
	MasterCidr                             string                    `json:"master_cidr"`
	HostVpcProjectName                     string                    `json:"host_vpc_project_name"`
	VpcSharedNetworkName                   string                    `json:"vpc_shared_network_name"`
	NodePrimaryCidrRange                   string                    `json:"node_primary_cidr_range"`
	PodCidrRange                           string                    `json:"pod_cidr_range"`
	ServicesCidrRange                      string                    `json:"services_cidr_range"`
	CustomClusterTags                      string                    `json:"custom_cluster_tags"`
	KmsKeyName                             string                    `json:"kms_key_name"`
	KmsKeyRingName                         string                    `json:"kms_key_ring_name"`
	DNSMaskingIPRanges                     string                    `json:"dns_masking_ip_ranges"`
	MachinesType                           string                    `json:"machines_type"`
	MaxNumberOfNodes                       string                    `json:"max_number_of_nodes"`
	MaxNumberOfPodsInANode                 string                    `json:"max_number_of_pods_in_a_node"`
	AdditionalNodePools                    []AdditionalNodePools     `json:"additional_node_pools"`
	ClusterNotification                    ClusterNotification       `json:"cluster_notification"`
	InternalIstioDetails                   InternalIstioDetails      `json:"internal_istio_details"`
	GlobalLoadBalancerDetails              GlobalLoadBalancerDetails `json:"global_load_balancer_details"`
	VenafiRelatedDetails                   VenafiRelatedDetails      `json:"venafi_related_details"`
	AdditionalCloudArmorIPRanges           string                    `json:"additional_cloud_armor_ip_ranges"`
	GrafanaHostNames                       string                    `json:"grafana_host_names"`
	KialiHostNames                         string                    `json:"kiali_host_names"`
	JaegerHostNames                        string                    `json:"jaeger_host_names"`
	ArgocdHostNames                        string                    `json:"argocd_host_names"`
	AppdynamicsRelated                     AppdynamicsRelated        `json:"appdynamics_related"`
	Storages                               []Storages                `json:"storages"`
}

type ClusterNotification struct {
	EmailList                  string `json:"email_list"`
	ServerlessVpcConnectorName string `json:"serverless_vpc_connector_name"`
}

type InternalIstioDetails struct {
	AllowedHostNames                          string `json:"allowed_host_names"`
	InternalIstioIngressgatewayIP             string `json:"internal_istio_ingressgateway_ip"`
	CertificatePfxAsJenkinsSecretFile         string `json:"certificate_pfx_as_jenkins_secret_file"`
	CertificatePfxPasswordAsJenkinsSecretText string `json:"certificate_pfx_password_as_jenkins_secret_text"`
	CertificateCertPemAsJenkinsSecretFile     string `json:"certificate_cert_pem_as_jenkins_secret_file"`
}

type GlobalLoadBalancerDetails struct {
	AllowedHostNames                          string `json:"allowed_host_names"`
	GlobalIPAddressName                       string `json:"global_ip_address_name"`
	CertificatePfxAsJenkinsSecretFile         string `json:"certificate_pfx_as_jenkins_secret_file"`
	CertificatePfxPasswordAsJenkinsSecretText string `json:"certificate_pfx_password_as_jenkins_secret_text"`
	CertificateCertPemAsJenkinsSecretFile     string `json:"certificate_cert_pem_as_jenkins_secret_file"`
	CertificateKeyPemAsJenkinsSecretFile      string `json:"certificate_key_pem_as_jenkins_secret_file"`
}

type VenafiRelatedDetails struct {
	PolicyName                                string `json:"policy_name"`
	TppCredentialsIDAsJenkinsUsernamePassword string `json:"tpp_credentialsId_as_jenkins_username_password"`
	TppURL                                    string `json:"tpp_url"`
	CommonName                                string `json:"common_name"`
	City                                      string `json:"city"`
	State                                     string `json:"state"`
	Organization                              string `json:"organization"`
}
type AppdynamicsRelated struct {
	ControllerKey string `json:"controller_key"`
	ControllerURL string `json:"controller_url"`
	AppName       string `json:"app_name"`
	AccountName   string `json:"account_name"`
}

type Storages struct {
	For  string `json:"for"`
	Kind string `json:"kind"`
	Size string `json:"size"`
}

type AdditionalNodePools struct {
	Name                   string `json:"name"`
	MachinesType           string `json:"machines_type"`
	ImageType              string `json:"image_type"`
	Taints                 string `json:"taints"`
	Labels                 Labels `json:"labels"`
	MaxNumberOfNodes       string `json:"max_number_of_nodes"`
	MaxNumberOfPodsInANode string `json:"max_number_of_pods_in_a_node"`
	DiskType               string `json:"disk_type"`
	DiskSize               string `json:"disk_size"`
}
type Labels struct {
	Dedicated string `json:"dedicated"`
	NodeTaint string `json:"node-taint"`
}

type Mattermost struct {
	Enabled        bool   `json:"enabled"`
	NotifyWebhook  string `json:"notifyWebhook"`
	StagesDisabled string `json:"stagesDisabled"`
}

type StageSettings struct {
	Deploy Deploy `json:"deploy"`
}

type Deploy struct {
	Script   string   `json:"script"`
	Settings Settings `json:"settings"`
}

type Settings struct {
	ArtifactFilePath     string            `json:"artifactFilePath"`
	EnvironmentVariables map[string]string `json:"environmentVariables"`
}
