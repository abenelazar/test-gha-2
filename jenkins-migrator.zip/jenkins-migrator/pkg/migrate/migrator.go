package migrate

import (
	"fmt"
	"log"
	"strconv"

	"github.com/abenelazar/jenkins-migrator/pkg/config"
	"github.com/hashicorp/hcl/v2/hclsyntax"
	"github.com/hashicorp/hcl/v2/hclwrite"
	"github.com/zclconf/go-cty/cty"
)

func init() {
	initializeGcpTypesSet()
}

// Function to generate HCL using hclwrite
func GenerateHCL(manifest Manifest) *hclwrite.File {
	// pretty.Print(manifest)

	file := hclwrite.NewEmptyFile()

	// Add GCP provider block
	rootBody := file.Body()

	WriteModuleBlock(rootBody, manifest)

	rootBody.AppendNewline()

	WriteProviderBlock(rootBody, manifest)

	rootBody.AppendNewline()

	WriteTerraformBlock(rootBody, manifest)

	rootBody.AppendNewline()

	WriteClusterBlock(rootBody, manifest)

	// Kubernetes cluster resource block

	// Node pool blocks
	WriteNodePoolBlock(rootBody, manifest)

	return file
}

func WriteModuleBlock(rootBody *hclwrite.Body, manifest Manifest) {
	for _, v := range manifest.Config.EnvironmentSettings {
		gcp := v.SettingsEnvironmentSettings.Infrastructure.Gcp
		moduleBlock := rootBody.AppendNewBlock(`module "gke"`, nil)
		moduleBlock.Body().SetAttributeValue("source", cty.StringVal("git::https://github.com/cvs-health-source-code/terraform-gke//modules/gitlab-jenkins-vpc-peering/modules/private-cluster?ref=US1702707/spike-jenkins-migration"))
		moduleBlock.Body().SetAttributeValue("project_id", cty.StringVal(gcp.ProjectName))
		moduleBlock.Body().SetAttributeValue("project_number", cty.StringVal("##########"))
		moduleBlock.Body().SetAttributeValue("name", cty.StringVal(gcp.ClusterName))
		moduleBlock.Body().SetAttributeValue("region", cty.StringVal(gcp.Region))
		moduleBlock.Body().SetAttributeValue("master_ipv4_cidr_block", cty.StringVal(gcp.MasterCidr))
		moduleBlock.Body().SetAttributeValue("network_project_id", cty.StringVal(gcp.HostVpcProjectName))
		moduleBlock.Body().SetAttributeValue("network", cty.StringVal(gcp.VpcSharedNetworkName))
		moduleBlock.Body().SetAttributeValue("subnetwork", cty.StringVal(gcp.NodePrimaryCidrRange))
		moduleBlock.Body().SetAttributeValue("ip_range_pods", cty.StringVal(gcp.PodCidrRange))
		moduleBlock.Body().SetAttributeValue("ip_range_services", cty.StringVal(gcp.ServicesCidrRange))

		maxNumberOfPodsInANode, err := strconv.ParseInt(gcp.MaxNumberOfPodsInANode, 10, 64)
		if err != nil {
			log.Fatalf("error converting MaxNumberOfPodsInANode to int, got: %v", err)
		}

		moduleBlock.Body().SetAttributeValue("default_max_pods_per_node", cty.NumberIntVal(maxNumberOfPodsInANode))
		cmekKeyName := fmt.Sprintf("projects/%s/locations/%s/keyRings/%s/cryptoKeys/%s", gcp.ProjectName, gcp.Region, gcp.KmsKeyRingName, gcp.KmsKeyName)
		moduleBlock.Body().SetAttributeValue("cmek_key_name", cty.StringVal(cmekKeyName))

		moduleBlock.Body().AppendNewline()

		moduleBlock.Body().SetAttributeValue("cluster_resource_labels", cty.ObjectVal(map[string]cty.Value{
			"gke-cluster": cty.StringVal(gcp.ClusterName),
		}))
		moduleBlock.Body().AppendNewline()
		moduleBlock.Body().SetAttributeValue("master_authorized_networks", cty.ListVal([]cty.Value{
			cty.ObjectVal(map[string]cty.Value{
				"cidr_block":   cty.StringVal(gcp.MasterCidr),
				"display_name": cty.StringVal(""),
			}),
		}))
		moduleBlock.Body().AppendNewline()
		machineType, exists := getMachineType(gcp.MachinesType)
		if !exists {
			log.Fatalf("invalid machine type found in json: %s", gcp.MachinesType)
		}

		maxNumberOfNodes, err := strconv.ParseInt(gcp.MaxNumberOfNodes, 10, 64)
		if err != nil {
			log.Fatalf("error converting MaxNumberOfNodes to int, got: %v", err)
		}
		moduleBlock.Body().SetAttributeValue("node_pools", cty.ListVal([]cty.Value{
			cty.ObjectVal(map[string]cty.Value{
				"name":               cty.StringVal("default-node-pool"),
				"machine_type":       cty.StringVal(machineType),
				"min_count":          cty.NumberIntVal(1),
				"max_count":          cty.NumberIntVal(maxNumberOfNodes),
				"image_type":         cty.StringVal("COS_CONTAINERD"),
				"auto_repair":        cty.BoolVal(true),
				"auto_upgrade":       cty.BoolVal(true),
				"preemptible":        cty.BoolVal(false),
				"initial_node_count": cty.NumberIntVal(1),
				"enable_secure_boot": cty.BoolVal(true),
			}),
		}))
		moduleBlock.Body().AppendNewline()
		moduleBlock.Body().SetAttributeValue("node_pools_oauth_scopes", cty.ObjectVal(map[string]cty.Value{
			"all": cty.ListVal([]cty.Value{
				cty.StringVal("https://www.googleapis.com/auth/devstorage.read_only"),
				cty.StringVal("https://www.googleapis.com/auth/logging.write"),
				cty.StringVal("https://www.googleapis.com/auth/monitoring"),
				cty.StringVal("https://www.googleapis.com/auth/servicecontrol"),
				cty.StringVal("https://www.googleapis.com/auth/service.management.readonly"),
				cty.StringVal("https://www.googleapis.com/auth/trace.append"),
			}),
		}))
		moduleBlock.Body().AppendNewline()
		moduleBlock.Body().SetAttributeValue("node_pools_labels", cty.ObjectVal(map[string]cty.Value{
			"all": cty.EmptyObjectVal,
		}))
		moduleBlock.Body().AppendNewline()
		moduleBlock.Body().SetAttributeValue("node_pools_metadata", cty.ObjectVal(map[string]cty.Value{
			"all": cty.ObjectVal(map[string]cty.Value{
				"serial-port-logging-enable": cty.BoolVal(false),
			}),
		}))
		moduleBlock.Body().AppendNewline()
		moduleBlock.Body().SetAttributeValue("node_pools_tags", cty.ObjectVal(map[string]cty.Value{
			"all": cty.ListVal([]cty.Value{
				cty.StringVal("gke-int-lb"), cty.StringVal("gce-int-lb"),
			}),
		}))
		moduleBlock.Body().AppendNewline()
		moduleBlock.Body().SetAttributeValue("node_pools_taints", cty.ObjectVal(map[string]cty.Value{
			"all": cty.ListValEmpty(cty.String),
		}))

	}
}

func WriteProviderBlock(rootBody *hclwrite.Body, manifest Manifest) {
	for _, v := range manifest.Config.EnvironmentSettings {
		gcp := v.SettingsEnvironmentSettings.Infrastructure.Gcp
		providerBlock := rootBody.AppendNewBlock("provider", []string{"google"})
		providerBlock.Body().SetAttributeValue("project", cty.StringVal(gcp.ProjectName))
		providerBlock.Body().SetAttributeValue("region", cty.StringVal(gcp.Region))
	}
}

func WriteClusterBlock(rootBody *hclwrite.Body, manifest Manifest) {
	for _, v := range manifest.Config.EnvironmentSettings {
		gcp := v.SettingsEnvironmentSettings.Infrastructure.Gcp
		clusterBlock := rootBody.AppendNewBlock("resource", []string{"google_container_cluster", "main"})
		clusterBlock.Body().SetAttributeValue("name", cty.StringVal(gcp.ClusterName))
		clusterBlock.Body().SetAttributeValue("location", cty.StringVal(gcp.Region))
		clusterBlock.Body().SetAttributeValue("initial_node_count", cty.NumberIntVal(1))
	}
}

func WriteNodePoolBlock(rootBody *hclwrite.Body, manifest Manifest) {
	for _, v := range manifest.Config.EnvironmentSettings {
		gcp := v.SettingsEnvironmentSettings.Infrastructure.Gcp
		for _, pool := range gcp.AdditionalNodePools {
			nodePoolBlock := rootBody.AppendNewBlock("resource", []string{"google_container_node_pool", pool.Name})
			nodePoolBody := nodePoolBlock.Body()
			nodePoolBody.SetAttributeValue("name", cty.StringVal(pool.Name))
			nodePoolBody.SetAttributeValue("location", cty.StringVal(gcp.Region))
			nodePoolBody.SetAttributeRaw("cluster", hclwrite.Tokens{{Type: hclsyntax.TokenQuotedLit, Bytes: []byte(` "${google_container_cluster.main.name}"`)}})

			// convert to int
			nodeCount, err := strconv.ParseInt(pool.MaxNumberOfNodes, 10, 64)
			if err != nil {
				log.Fatalf("error converting MaxNumberOfNodes to int, got: %v", err)
			}

			nodePoolBody.SetAttributeValue("node_count", cty.NumberIntVal(nodeCount))
			nodeConfigBlock := nodePoolBody.AppendNewBlock("node_config", []string{})
			nodeConfigBlock.Body().SetAttributeValue("machine_type", cty.StringVal(pool.MachinesType))
		}
	}
}

func WriteTerraformBlock(rootBody *hclwrite.Body, manifest Manifest) {
	terraformBlock := rootBody.AppendNewBlock("terraform", nil)
	terraformBlock.Body().SetAttributeValue("required_version", cty.StringVal(">= 1.0.8"))

	requiredProvidersBlock := terraformBlock.Body().AppendNewBlock("required_providers", nil)

	for _, val := range config.GlobalConfig.Providers {
		providerBlock := requiredProvidersBlock.Body().AppendNewBlock(val.Name, nil)
		providerBlock.Body().SetAttributeValue("source", cty.StringVal(val.Source))
		providerBlock.Body().SetAttributeValue("version", cty.StringVal(val.Version))
	}
}

func getMachineType(awsType string) (string, bool) {
	// check if it's already a GCP machine type
	if _, exists := gcpMachineTypes[awsType]; exists {
		return awsType, true
	}

	// convert from AWS to GCP
	gcpType, exists := awsToGcpMap[awsType]
	return gcpType, exists
}

// gcpTypesSet holds a set of GCP machine types for quick lookup.
var gcpMachineTypes = make(map[string]struct{})

// initializeGcpTypesSet initializes gcpTypesSet with values from awsToGcpMap.
func initializeGcpTypesSet() {
	for _, machineType := range awsToGcpMap {
		gcpMachineTypes[machineType] = struct{}{}
	}
}
