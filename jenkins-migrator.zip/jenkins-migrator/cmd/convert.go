/*
Copyright © 2024 NAME HERE <EMAIL ADDRESS>
*/
package cmd

import (
	"encoding/json"
	"os"

	"github.com/abenelazar/jenkins-migrator/pkg/migrate"
	"github.com/spf13/cobra"
)

// convertCmd represents the convert command
var convertCmd = &cobra.Command{
	Use:   "convert",
	Short: "A brief description of your command",
	Long: `A longer description that spans multiple lines and likely contains examples
and usage of using your command. For example:

Cobra is a CLI library for Go that empowers applications.
This application is a tool to generate the needed files
to quickly create a Cobra application.`,
	Run: Convert,
}

func Convert(cmd *cobra.Command, args []string) {
	input := cmd.Flag("input").Value.String()
	if input == "" {
		cmd.PrintErr("input file is required")
		os.Exit(1)
	}

	manifest, err := ReadManifest(cmd.Flag("input").Value.String())
	if err != nil {
		cmd.PrintErrf("error reading manifest '%s', got: %v\n", input, err)
		os.Exit(1)
	}

	hcl := migrate.GenerateHCL(*manifest)
	// output HCL to stdout or file
	if output := cmd.Flag("output").Value.String(); output != "" {
		os.WriteFile(output, hcl.Bytes(), 0644)
		cmd.Printf("result written to %s\n", output)
		return
	}

	os.Stdout.Write(hcl.Bytes())
}

func ReadManifest(filename string) (*migrate.Manifest, error) {
	var manifest migrate.Manifest

	// Reading JSON from a file
	b, err := os.ReadFile(filename)
	if err != nil {
		return nil, err
	}

	// Unmarshalling JSON into a struct
	err = json.Unmarshal(b, &manifest)
	if err != nil {
		return nil, err
	}

	return &manifest, nil
}

func init() {
	// flags
	convertCmd.Flags().StringP("input", "i", "", "Input file to convert")
	convertCmd.MarkFlagRequired("input")

	// output file flag
	convertCmd.Flags().StringP("output", "o", "", "Output file to write to")

	rootCmd.AddCommand(convertCmd)

	// Here you will define your flags and configuration settings.

	// Cobra supports Persistent Flags which will work for this command
	// and all subcommands, e.g.:
	// convertCmd.PersistentFlags().String("foo", "", "A help for foo")

	// Cobra supports local flags which will only run when this command
	// is called directly, e.g.:
	// convertCmd.Flags().BoolP("toggle", "t", false, "Help message for toggle")
}
