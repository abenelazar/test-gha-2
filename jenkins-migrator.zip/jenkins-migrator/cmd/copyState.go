/*
Copyright © 2024 NAME HERE <EMAIL ADDRESS>
*/
package cmd

import (
	"os"

	"github.com/abenelazar/jenkins-migrator/pkg/sync"
	"github.com/spf13/cobra"
)

// copyStateCmd represents the copyState command
var copyStateCmd = &cobra.Command{
	Use:   "copyState",
	Short: "A brief description of your command",
	Long: `A longer description that spans multiple lines and likely contains examples
and usage of using your command. For example:

Cobra is a CLI library for Go that empowers applications.
This application is a tool to generate the needed files
to quickly create a Cobra application.`,
	Run: func(cmd *cobra.Command, args []string) {
		err := sync.CopyObject(cmd.Context(), "sourceBucket", "destinationBucket", "sourceObject", "destinationPath")
		if err != nil {
			cmd.PrintErr(err)
			os.Exit(1)
		}
	},
}

func init() {
	copyStateCmd.Flags().StringP("sourceBucket", "s", "", "Source bucket to copy from")
	copyStateCmd.MarkFlagRequired("sourceBucket")

	copyStateCmd.Flags().StringP("destinationBucket", "d", "", "Destination bucket to write to")
	copyStateCmd.MarkFlagRequired("destinationBucket")

	copyStateCmd.Flags().StringP("sourceObject", "o", "", "Source object to copy from")
	copyStateCmd.MarkFlagRequired("sourceObject")

	copyStateCmd.Flags().StringP("destinationPath", "p", "", "Destination path to write object to")
	copyStateCmd.MarkFlagRequired("destinationPath")

	rootCmd.AddCommand(copyStateCmd)

	// Here you will define your flags and configuration settings.

	// Cobra supports Persistent Flags which will work for this command
	// and all subcommands, e.g.:
	// copyStateCmd.PersistentFlags().String("foo", "", "A help for foo")

	// Cobra supports local flags which will only run when this command
	// is called directly, e.g.:
	// copyStateCmd.Flags().BoolP("toggle", "t", false, "Help message for toggle")
}
