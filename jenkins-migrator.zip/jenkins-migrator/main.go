/*
Copyright © 2024 NAME HERE <EMAIL ADDRESS>
*/
package main

import (
	"fmt"

	"github.com/abenelazar/jenkins-migrator/cmd"
	"github.com/abenelazar/jenkins-migrator/pkg/config"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

func main() {
	cmd.Execute()
}

func initConfig() {
	viper.AddConfigPath(".")      // or any path where your config file resides
	viper.SetConfigName("config") // no need to include file extension
	viper.SetConfigType("yaml")   // this depends on your config file format

	viper.AutomaticEnv() // override settings in config file with environment variables

	if err := viper.ReadInConfig(); err != nil {
		fmt.Printf("Error reading config file, %s", err)
	}

	if err := viper.Unmarshal(&config.GlobalConfig); err != nil {
		fmt.Printf("Unable to decode into struct, %v", err)
	}

}

func init() {
	cobra.OnInitialize(initConfig)
	// Other initialization code...
}
